package pe.edu.upeu.examen.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import pe.edu.upeu.examen.entity.Grado;

public interface GradoRepository extends JpaRepository<Grado,Long>{
	

}
