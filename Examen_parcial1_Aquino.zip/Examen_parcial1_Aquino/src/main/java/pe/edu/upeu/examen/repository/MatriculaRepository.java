package pe.edu.upeu.examen.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import pe.edu.upeu.examen.entity.Matricula;

public interface MatriculaRepository extends JpaRepository<Matricula,Long>{

}
