package pe.edu.upeu.examen.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import pe.edu.upeu.examen.entity.Alumno;

public interface AlumnoRepository extends JpaRepository<Alumno,Long>{

}
