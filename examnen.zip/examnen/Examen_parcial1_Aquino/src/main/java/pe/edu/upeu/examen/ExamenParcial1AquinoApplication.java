package pe.edu.upeu.examen;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExamenParcial1AquinoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExamenParcial1AquinoApplication.class, args);
	}

}
