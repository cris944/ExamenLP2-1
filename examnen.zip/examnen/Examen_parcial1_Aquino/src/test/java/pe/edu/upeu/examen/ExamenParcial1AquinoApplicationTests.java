package pe.edu.upeu.examen;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExamenParcial1AquinoApplicationTests {

	@Test
	void contextLoads() {
	}

}
